#ifndef __SYSTEMCLOCK_H
#define __SYSTEMCLOCK_H

#include "stm32f7xx_hal.h"

void SystemClock_Config(void);

#endif /* __SYSTEMCLOCK_H */

